<?php

namespace App\Http\Controllers\Owner;

use App\Car;
use App\CarGallery;
use App\Category;
use Illuminate\Support\Str;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Admin\CarRequest;

class MyCarController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $cars = Car::with(['galleries','category'])
                ->where('users_id',Auth::user()->id)
                ->get();
        return view('pages.owner.dashboard-mycars', [
            'cars' => $cars
        ]);
    }

    public function details(Request $request, $id)
    {
        $car = Car::with((['galleries','user','category']))->findOrFail($id);
        $categories = Category::all();
        return view('pages.owner.dashboard-mycars-detail',[
            'categories' => $categories,
            'car' => $car
        ]);
    }

    public function uploadGallery(Request $request)
    {
        $data = $request->all();

        $data['photos'] = $request->file('photos')->store('assets/car','public');

        CarGallery::create($data);

        return redirect()->route('owner-mycars-detail', $request->cars_id);
    }

    public function deleteGallery(Request $request, $id)
    {
        $item = CarGallery::findOrFail($id);
        $item->delete();

        return redirect()->route('owner-mycars-detail', $item->cars_id);
    }

    public function create()
    {
        $categories = Category::all();
        return view('pages.owner.dashboard-mycars-add',[
            'categories' => $categories
        ]);
    }

    public function store(CarRequest $request)
    {
        $data = $request->all();

        $data['slug'] = Str::slug($request->name);
        $car = Car::create($data);

        $gallery = [
            'cars_id' => $car->id,
            'photos' => $request->file('photo')->store('assets/car','public')
        ];

        CarGallery::create($gallery);

        return redirect()->route('owner-mycars');

    }

    public function update(CarRequest $request, $id)
    {
        $data = $request->all();

        $item = Car::findOrFail($id);

        $data['slug'] = Str::slug($request->name);

        $item->update($data);

        return redirect()->route('owner-mycars');
    }

    public function destroy($id)
    {
        $item = Car::findOrFail($id);
        $item->galleries()->delete();
        $item->delete();

        return redirect()->route('owner-mycars');
    }
}
